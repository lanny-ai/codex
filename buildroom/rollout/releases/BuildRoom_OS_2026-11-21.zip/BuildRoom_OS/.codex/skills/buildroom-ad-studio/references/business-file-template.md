# Build Room Business File

_One file. Every Build Room session reads it before asking you anything, and updates it before ending. It stays in your Build Room folder, where every session finds it._

**Owner:** [your name]
**Business:** [business name]
**File version:** 1.12
**Last updated:** [YYYY-MM-DD] by [session name]

> **How to use this file:** Leave it in your Build Room folder. Each session reads it, skips every question it already answers, saves its changes here and tells you what changed. You can edit anything by hand at any time — your edits win.

---

## 1. Business Snapshot

**Status:** not started · **Updated:** — · **By:** —

- **What I do:**
- **Who I serve (niche + segment):**
- **Core result I deliver:**
- **Current price / price range:**
- **Lead sources today (how people find me):**
- **Tools:** email platform: — · CRM: — · website/page builder: — · automation: —
- **How someone books or buys (link if there is one):**
- **Background and credentials:**
- **A typical client result (the honest middle case, or "none yet"):**
- **Never claim or promise:**
- **Retired lines** (never used again in any output, by any session — e.g. a credibility story, a claim, an old offer; each one in quotation marks, separated by semicolons):

---

## 2. Ideal Client Avatar

**Status:** not started · **Updated:** — · **By:** —
_Built by: Ideal Client Avatar session_

- **ICA name (fictional):**
- **One-line profile (who + situation):**
- **Job To Be Done** — functional: — · emotional: — · identity: —
- **Pain stack** — surface: — · emotional: — · identity (inner monologue): —
- **Dream state** — 90 days: — · 1 year: —
- **Switching forces** — push: — · pull: — · anxiety: — · habit: —
- **Awareness stage (Schwartz):**
- **Buying trigger (what makes them act now):**
- **Top objections** — spoken: — · unspoken: —
- **Negative avatar (who I refuse to serve, and why):**
- **Sourced language** (exact phrases with provenance: `[client]` or `[web: source]`):
  1. —
- **Hypothesis language** (generated or guessed, `[hypothesis]` — never quote as a client's words):
  1. —
- **Audience Playbook:** [filename or link]
- **Full ICA document:** [filename or link]

---

## 3. Signature Offer

**Status:** not started · **Updated:** — · **By:** —
_Built by: Signature Offer session · Requires: §2_

- **Offer name:**
- **Core transformation promise (one sentence):**
- **Engagement structure (length, format):**
- **Phases + outcome per phase:**
  - Phase 1: — → outcome: —
- **Named deliverables:**
- **Value stack total:** $ — · **Investment:** $ —
- **Guarantee (full wording):**
- **60-second pitch:**
- **The one belief (16-word):**
- **Urgency (why now, real):**
- **Full offer document:** [filename or link]
- **Offer Deep Dive document:** [filename or link]

---

## 4. Positioning & Messaging

**Status:** not started · **Updated:** — · **By:** —
_Built by: Positioning & Messaging session · Requires: §2, §3_

- **Competitive alternative (what my best-fit client would do if I didn't exist):**
- **Market category:**
- **Core differentiator (most ownable):**
- **Positioning statement:**
- **Value proposition (one sentence):**
- **Tagline:**
- **Villain statement (what's wrong with how my space operates):**
- **For you if (top 3):**
- **Not for you if (top 3):**
- **Unfair advantage:**
- **Market sophistication** (how many promises like mine this buyer has already heard · stage 1–5 · evidence):
- **Belief to move** (the one thing a buyer at the §2 awareness stage must believe to take the next step):
- **Full Messaging Bible:** [filename or link]

---

## 5. Offer Page

**Status:** not started · **Updated:** — · **By:** —
_Built by: Offer Page Copy session · Requires: §2, §3, §4_

- **Chosen headline:**
- **Page status:** draft / live · **URL:** —
- **Proof assets used (results, testimonials, composites — labeled):**
- **Credibility anchor:**
- **Full page copy document:** [filename or link]

---

## 6. Funnel & Automation

**Status:** not started · **Updated:** — · **By:** —
_Built by: Funnel Map session · Requires: §1; better with §2, §3_

- **Traffic strategy** (primary · secondary · test · first-lead window · status):
- **Value ladder** — bait/entry: — · core: — · backend/continuity: —
- **Funnel type + single conversion event:**
- **Funnel map (compact step list):**
- **Biggest drop-off point:**
- **Email sequence:** [name · # emails · doc link]
- **Automation trigger map (compact):**
- **First build priority:**
- **CRM build** (location · tags/fields pushed · workflows built · launch test passed · date):
- **Metrics** — opt-in rate: — · show-up rate: — · close rate: —
- **Funnel scorecard** (location · cadence · last run · top leak):
- **Leak finder routine** (ON/OFF · cadence · delivers to):

---

## 7. Lead Capture

**Status:** not started · **Updated:** — · **By:** —
_Built by: Lead Capture session · Requires: §6_

- **Lead magnet (format + title):**
- **Landing page:** status: — · URL: —
- **Application** (status · URL · questions · qualifying rule · answers land in):
- **Thank-you page + delivery automation:** status: —

---

## 9. Operations & SOPs

**Status:** not started · **Updated:** — · **By:** —
_Built by: SOP Creator session · Requires: §1_

- **Processes documented** (name · owner · last reviewed):
  - —
- **Top undocumented processes** (from triage, by priority):
- **SOP library location:**
- **Naming convention:**
- **Review cadence:**
- **Maintenance trigger** (the event that forces an update):
- **Automation candidates** (process · go / no-go / partial · stage: mapped / evals / shadow / approve-each / autonomous):
  - —
- **Full Operations Pack:** [filename or link]

---

## 10. Team & Hiring

**Status:** not started · **Updated:** — · **By:** —
_Built by: Hiring Ad + Interview Kit session · Requires: §9_

- **Role** (title · hours/wk · contractor/employee · pay range):
- **Mission (one sentence):**
- **Outcomes** (measurable, with timeframe):
  1. —
- **SOPs this role bundles:**
- **90-day standard:**
- **Ad status** (drafted / posted where / closed):
- **Funnel stage** (screening / work sample / interviews / references / offer / hired):
- **Hire** (name · start date · trial end):
- **Full Hiring Kit:** [filename or link]

---

## 11. Training & Onboarding

**Status:** not started · **Updated:** — · **By:** —
_Built by: Team Training Doc Builder session · Requires: §9, §10_

- **Training Handbook location:**
- **Modules** (SOP · checkout status · date · observer):
  - —
- **Onboarding calendar** (start date · current week):
- **Sign-off owner:**
- **FAQ location:**
- **Maintenance trigger** (the event that forces a handbook update):
- **Full Training Handbook:** [filename or link]

---

## 12. Weekly Ops

**Status:** not started · **Updated:** — · **By:** —
_Built by: Weekly Ops Dashboard session · Requires: §9, §11_

- **Metrics** (name · owner · goal · source):
  - —
- **Weekly ops meeting** (day · time · attendees):
- **Dashboard location:**
- **Routine** (ON/OFF · schedule · delivers to · connectors):
- **Current constraint** (one line · since):
- **Decision log location:**
- **Full Ops Pack:** [filename or link]

---

## 13. Build Plan

**Status:** not started · **Updated:** — · **By:** —
_Built by: Brainstorm Capture (and any session that produces an idea) · Requires: —_

- **Ideas & builds** (idea · source · status · owner · next step · produced):
  - —
  - _Statuses: captured → scheduled → building → shipped · parked_
- **Parked** (idea · why · revisit date):
  - —
- **Open questions carried forward:**
  - —
- **Brainstorm log location:**
- **Last brainstorm** (date · framing question):

---

## 14. Lead Generation Engine

**Status:** not started · **Updated:** — · **By:** —
_Built by: Lead Gen Machine (four modules, one session each); LinkedIn Engine (the LinkedIn lines) · Requires: §1; best with §2, §3_

- **Modules run** (module · date · status):
  - 1 Warm Network: — · 2 Outreach Machine: — · 3 Referral System: — · 4 Content + Pipeline: —
- **Warm network** (contacts audited · tier-A count · scorecard location):
- **Outreach** (channel · list source · message doc · 5-touch sequence doc):
- **Referral system** (trigger moments · ask-script doc · partners):
- **Content** (platform · cadence · content type · calendar location):
- **Pipeline tracker** (location · stages):
- **Weekly habit** (day · time · minutes):
- **30-day targets** (conversations · discovery calls · deals):
- **Results to date** (conversations · calls · clients · best channel):
- **LinkedIn engine** (pillars · cadence and formats · profile rebuilt date · Featured asset · button or Services):
- **LinkedIn routine** (daily minutes · watch list · story bank · calendar · pipeline file · scorecard day):
- **LinkedIn last 4 weeks** (posts · comments · conversations · calls · clients · best pillar and format):
- **Full Lead Gen Pack:** [filename or link]

---

## 15. Sales Conversations

**Status:** not started · **Updated:** — · **By:** —
_Built by: Sales Conversations session · Requires: §3; best with §2, §4_

- **Scenario** (inbound / outbound / referral / appointment-set):
- **Script location:**
- **Weak stage + what changed:**
- **Top objections + one-line response:**
  1. —
- **Role-play dates:**
- **Call metrics** (booked · held · closed, weekly):
- **Full Sales Script:** [filename or link]

---

## 16. Follow-Up Engine

**Status:** not started · **Updated:** — · **By:** —
_Built by: Decision Machine session · Requires: §3, §6; best with §2, §7_

- **Core belief (one sentence):**
- **The five beliefs** (surface · identity · reframe · proof · anticipation):
  1. —
- **Campaign map** (campaign · entry tag · exit tag · belief · awareness level · status):
  - —
- **Tag architecture doc:** · **tag count:**
- **Build status** (tags · fields · workflows · messages — built / verified):
- **Engagement tracker:** on/off · **Stagger:** on/off (list size)
- **Reactivation** (list size · verified · sunset sent):
- **Deliverability** (SPF/DKIM/DMARC checked · unsubscribe · complaint rate):
- **Metrics to watch** (open · reply · booked · per campaign):
- **Full Decision Machine Pack:** [filename or link]

---

## 17. Founder Compass

**Status:** not started · **Updated:** — · **By:** —
_Built by: Compass session · Requires: —_

- **Compass statement:**
- **Top values (3):**
- **Life philosophy (one sentence):**
- **Personality pattern (plain words):**
- **Zone of genius:**
- **Spark zone:**
- **Drain zone:**
- **Blind spots:**
- **Unique truth:**
- **Communication style (how I sound at my best):**
- **Full Compass document:** [filename or link]

---

## 18. Advertising

**Status:** not started · **Updated:** — · **By:** —
_Built by: Ad Studio · Requires: §2, §3; best with §4, §7_

- **Budget** (amount · period) · **margin per sale before ads:**
- **Paid traffic** (on / not yet · why):
- **Success metric** (cost per qualified lead or booked call · what counts as qualified · where it is counted):
- **Never-say claims:**
- **Wrong fit** (who the offer is not for):
- **Proof vault** (location · consented testimonials · real numbers · review count + rating · founder photos):
- **Brand kit** (1–3 locked assets: face · colour · name · line · shape · fonts; colours and fonts: see §22 once it is complete):
- **Platforms** (Meta ad account ready · LinkedIn · who approves):
- **Generation** (provider · monthly cap in provider units · likeness consent on file):
- **Past results** (campaign · dates · spend · leads · qualified · counting rule):
  - —
- **Current cycle** (month · concepts · hooks · status · winner · next brief):
- **Learning library:** [ads/learning-library.csv]
- **Launch kit:** [folder]

---

## 19. Video

**Status:** not started · **Updated:** — · **By:** —
_Built by: Video Director · Requires: §1, §2; best with §3, §4, §17_

- **Playbooks run** (ad · content · sales · proof — last date each):
- **Footage library** (location · A-roll takes · screen recordings · interviews):
- **Video brand kit** (brand cue · end card · caption template or style · music source + licence):
- **Consent** (my likeness + voice: yes/no, date, where · avatar twin: yes/no, scope, date):
- **Content series** (pillars · cadence · platform · volume mode on/off):
- **Testimonials collected** (count · latest · consent forms location):
- **Video library** (location · last delivered: title · playbook · date):
- **Results to watch** (ad: cost per qualified lead · content: watch time, follows · sales: booked calls · proof: testimonials):

---

## 20. Launches & Events

**Status:** not started · **Updated:** — · **By:** —
_Built by: Event Launcher (the Webinar line: Webinar Builder) · Requires: §1, §2, §3; best with §4, §6, §16, §17_

- **Current launch** (name · format · dates and time zone · goal in buyers and cash · status):
- **The one belief** (and the three that support it):
- **First-win tool** (what registrants finish before the event · where):
- **The close** (checkout, call or both · tiers and prices · the real deadline, or none and when the window ends · payment plans · first step · VIP):
- **Fill plan** (list segments · invitation sequence · partners · ads · registration target):
- **Show-up plan** (calendar file · reminder schedule · pre-work · moderator):
- **Launch gate** (pre-invite · day before · close morning · cart — each GO or HOLD with its date):
- **Results** (registered · live Day 1 / 2 / 3 · at the close · buyers by tier or calls booked, held, closed · cash · booked · refunds):
- **Lessons for next time** (top three leaks · what to protect):
- **Webinar** (talk version · format and length · the three beliefs · last check GO or HOLD and date · last rehearsal score · last run's three lessons · folder launches/<slug>/webinar/):
- **Past launches** (name · date · registered · buyers · cash — one line each):
  - —
- **Launch folder:** [launches/YYYY-MM-name/]

---

## 21. Search & Answer Presence

**Status:** not started · **Updated:** — · **By:** —
_Built by: Search & Answer Engine · Requires: §1, §2; best with §3, §4, §14, §18_

- **Website** (builder · domain · who edits · Search Console verified · Bing verified · search crawlers allowed):
- **Google Business Profile** (eligible or not · verified · primary category · score · reviews count + rating · last reply · last photo · last post):
- **Question map** (questions mapped · rated · next three):
- **Answer pages** (published · last published · last updated · service pages · hub):
- **Listings** (live · details match · last checked):
- **Review loop** (how asked · when · link saved · asks per month · reviews per month · reply rule):
- **Author & reviewer** (named author · credentials line · reviewer for regulated topics):
- **Scope rules** (regulated profession · scope note · never-say claims apply):
- **Monthly check** (prompts · engines · last run · seen in N of M · top competitor):
- **Weekly routine** (day · minutes · profile · one page · one mention a month):
- **Results** (profile calls + directions · bookings by "how did you find us" · Search Console clicks + AI impressions · Bing citations · first citation date):
- **Search folder:** [search/]

---

## 22. Design System

**Status:** not started · **Updated:** — · **By:** —
_Built by: Website Design Studio · Requires: §1, §2; best with §3, §4, §5 or §7, §18_

- **Taste vault** (location · references · collections · "what I keep choosing"):
- **Directions tried** (names · chosen · why):
- **Locked system** (palette · fonts · type scale · corners · spacing · motion):
- **Imagery rules** (own photos / generated · provider · consent):
- **Do / don't:**
- **Files** (design-system.md · tokens.json · tokens.css · slides.json · first page):
- **Used by** (skills that have read it · last date):

---

## 23. Book

**Status:** not started · **Updated:** — · **By:** —
_Built by: AI Momentum Labs Book Builder · Requires: §1, §2; best with §3, §4, §17, §18_

- **Book** (title · promise · reader):
- **Shape** (chapters · target words · words measured):
- **Stage** (intake · outline · draft · memo · sample · edit · review · facts · readers · copyedit · regression · gate):
- **Last gate** (GO or FIX · date · edition):
- **Readers** (real: invited · responded · thresholds met; simulated runs, kept apart · waiver):
- **Open issues** (P0 · P1 · P2 · P3):
- **Book folder:** [book/]

---

## 24. Speaking

**Status:** not started · **Updated:** — · **By:** —
_Built by: Speaking Engine · Requires: §1, §2; best with §3, §4, §6, §17, §18, §22_

- **Goal** (clients first, fees second · talks by a date):
- **Talks on file** (title · promise · lengths):
- **Speaker kit** (bio · one-sheet · where they live):
- **Stages** (found · vetted · pitched · answered · booked · dropped):
- **Talks given** (count · people in rooms · leads · calls · clients; the member's own counts):
- **Next step** (what · date):
- **Speaking folder:** [speaking/]

---

## 25. Company Blueprint

**Status:** not started · **Updated:** — · **By:** —
_Built by: Company Blueprint · Requires: §1, §3; best with §9, §10, §11, §12, §17_

- **Aim** (the life the owner wants · where the business is going · the work they keep):
- **Functions** (each one · who covers it today):
- **Positions** (each seat · who holds it):
- **Measures** (defined · measured · with a target; the member's own numbers):
- **Hand-off list** (first to hand off · its first step):
- **Step** (1 to 5 · next step) · **Review rhythm:**
- **Blueprint folder:** [blueprint/]

---

## 8. Session Log

| Date | Session | Outputs produced | Status | Rating (1–5) | Notes |
|---|---|---|---|---|---|
| | | | | | |
