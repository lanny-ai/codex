# The content system

Three posts a week a busy expert can keep up for a year, built from their own words, on two or three topics that point at the offer. The skill drafts; the member edits and posts.

## 1. Pillars (two or three, held for at least 90 days)

The feed matches posts to readers by topic (`linkedin-principles.md` §1). A member who posts about everything gives the feed, and readers, nothing to file them under [practitioner: van der Blom's topic data]. Build the pillars from the file:

| Pillar | Comes from | Job |
|---|---|---|
| **Expertise and point of view:** how the member thinks about the buyer's core problem | §3 method, §4 villain and differentiator | Authority; earns the follow |
| **Proof:** client stories, before and after, numbers, process breakdowns | §5 and §18 proof (consented), §3 results | Converts; the bridge to a call |
| **Personal and values:** decades of lessons, mistakes, why the member works this way | §17 Compass, §1 story | Trust; makes the member a person |

Optional fourth: **the invitation** (offer posts), used every two to four weeks.

Name each pillar in the buyer's words, not the member's ("Cash flow for family firms", not "Financial leadership"). Show the three, the member confirms or edits. Write them to §14.

## 2. Voice first: capture before drafting

The member's specific stories are the moat; generic text is penalised (`linkedin-principles.md` §7). So the skill never invents a story, a client, a number or a quote. It collects them.

**The weekly capture (20 minutes, voice or typed):** ask three prompts drawn from the matrix below, one at a time. The member answers out loud (a voice memo transcribed, or typed). Good prompts ask for a specific moment:
- "Tell me about the last time a client [situation from §2]. What happened, what did you do, what changed?"
- "What do most people in your field get wrong about [pillar topic]? When did you first see that?"
- "What's a mistake you made in year [N] that you'd stop a younger you from making?"
- "A client asked you [real question from §15 or §2 objections]. What did you say?"

Keep a **story bank** (`linkedin/story-bank.md`): each story with the date told, the pillar, the facts (who, when, numbers), whether a client is named and if consent exists, and which posts have used it.

## 3. The idea matrix

Pillars × post styles = ideas [practitioner: Justin Welsh's content matrix, adapted]. Five styles to start:

| Style | Shape |
|---|---|
| Step-by-step | "How to [outcome] in [n] steps (without [pain])" |
| Contrarian | "[Common advice] is wrong for [buyer]. Here's what I've seen in [N] years." |
| Observation | "Something I keep seeing with [buyer group]…" + pattern + what it means |
| Story | Story → the lesson → one action → a real question (SLAY) [practitioner: Lara Acosta] |
| Proof | Situation → what we changed → the result with numbers and a timeframe → the lesson for you |

Three pillars × five styles = fifteen cells; each cell yields several posts. Fill the matrix with one-line headlines from the story bank and the file; keep it in `linkedin/matrix.md`.

## 4. Post archetypes (pick from these; each needs the member's own material)

| # | Archetype | Template | Who teaches it |
|---|---|---|---|
| 1 | Story (SLAY) | Story → lesson → one concrete action → a real question | Lara Acosta |
| 2 | Problem, agitate, solve | The buyer's problem → its real cost → the member's approach | Matt Barker |
| 3 | Step-by-step | "How to [outcome] in [n] steps" + numbered steps | Justin Welsh |
| 4 | Contrarian, grounded | "Unpopular, but true after [N] years: [claim]. Here's why." | Welsh; data favours contrarian hooks |
| 5 | Observation | "I've noticed something about [buyer group] lately…" | Welsh |
| 6 | Client case | Situation → change → result in numbers → lesson (consented or anonymised) | practitioner consensus |
| 7 | Behind the scenes | "What actually happens in week one of working with me" | general |
| 8 | Mistake | "The $40K mistake I made in year 3" + the lesson | general |
| 9 | Career-arc lesson | "25 years in [field]: 7 things I'd tell my 35-year-old self" | general; the experience moat |
| 10 | Then and now | "How [thing] worked in 2005 vs 2026, and what that means for you" | general |
| 11 | Myth-buster | "3 myths about [topic] that cost [buyer] money" | general |
| 12 | Named model | "The [Name] Rule: [one line]" + how to use it + a simple visual | Sahil Bloom |
| 13 | Give away the method | "Here's the exact process I charge clients for, free" | Alex Hormozi's principle |
| 14 | Framework carousel | A save-worthy one-page method as a document carousel | Chris Donnelly; data favours documents |
| 15 | Question of the week | "A client asked me [real question]. My answer:" | general; strong for services |
| 16 | News + point of view | A development → what most miss → what to do | general; Edelman's "make buyers rethink" |
| 17 | Who I'm not for | Define the wrong client to sharpen the right one | general |
| 18 | Soft offer | "I'm taking on [n] new clients for [offer] in [month]. For [who]. Not for [who]. DM me if it's you." Use a number only when the member has set it; otherwise drop it ("I'm taking on new clients for…"). Never comment-gated | general |
| 19 | Testimonial spotlight | The client's words (consented, verbatim) + the story behind the result | practitioner consensus |
| 20 | Punchy advice | 3 to 6 lines, one sharp piece of advice | Jasmin Alić |

Never: "comment KEYWORD to get it", "agree?", reaction polls, "repost if", tagging people who were not involved.

## 5. The weekly mix (three posts)

- **Post 1, early week:** expertise or contrarian (reach within the topic).
- **Post 2, midweek:** proof or story (trust and conversion). Format: document carousel when the material is a method; image otherwise.
- **Post 3, late week:** personal, a lesson, or (every second to fourth week) the soft offer.
- One call to action in most posts, soft: a P.S. pointing to the Featured diagnostic, or "DM me if you're dealing with this". One explicit offer post every two to four weeks. The profile sells the rest of the time. [synthesis of Alić's "sell from your content, not in it" and Welsh's clear calls to action]
- Days: midweek, in the buyer's working hours (studies disagree on the exact days: Buffer's 2026 data ranks Wednesday, Thursday and Friday highest, older studies Tuesday to Thursday); test Friday; the member's own analytics overrule after four weeks.

## 6. Writing each post

Every post goes through **Kern** (`kern-framework.md`): short, one person to one person, specific. A long story-led post or a newsletter issue goes through **Halbert** (`halbert-writing-system.md`). One post per output; the member approves or edits before the next.

- **The first ~140 characters carry the post.** LinkedIn truncates with "see more" at about 140 characters on mobile (about 210 on desktop; LinkedIn does not publish the number, and line breaks move it). The opening must name the reader, the situation or the claim plainly inside that space.
- **Length:** a text post carries a whole idea, usually 1,300 to 2,500 characters: AuthoredUp's 372,000-post data peaks between 1,300 and 2,500, Ordinal's at 2,000 to 3,000; the weakest bands are about 600 to 1,300 (AuthoredUp) and 600 to 1,500 (Ordinal). **Image posts and carousel captions are the exception:** AuthoredUp's newer 709,000-post data puts them at about 800 to 1,000 characters (a small gain), because the image or document carries the idea. A short punchy post (under 600) now and then is fine.
- **The topic in the first lines,** in the words the buyer uses, so both readers and the feed's model know what it is about.
- **Specifics over adjectives:** a number, a name (consented), a year, a place.
- **Short paragraphs,** one idea each; white space for reading on a phone, not "broetry" on every line.
- **End with a real question** the reader can answer from experience, or a soft call to action. Not "Agree?".
- **No hashtags needed;** at most one link, usually none.
- **Avoid the AI tells:** cascades of em dashes, "Here's the thing:", "Let that sink in", triplets of abstractions, emoji bullets, generic questions, "In today's fast-paced world".
- **The three tests on every line** [Harry Dry]: can I picture it, can I prove it, could only this member say it.
- **Draft label:** each draft is marked "draft, edit before posting" and lists the facts it used from the story bank, so the member can check them. Under it: the character count and the first 140 characters exactly as they will show before "see more".

**Kern for LinkedIn.** The Kern and Halbert references are written for emails and sales letters and are shared with the Copy Engine, so on LinkedIn they are applied with these limits. "Kern checks pass" means: one objective per post; the reader's belief that is being changed is named; the help is inside the post, not behind a link or a DM; a damaging admission where one is true; every number from the file or the story bank. And never, on LinkedIn: capitals for emphasis, an urgency P.S., scarcity or countdowns, risk-reversal or guarantee language unless the member has signed the guarantee off, stock lines (Halbert's 45 to 65 list included), or anything that reads like a growth creator.

## 7. Formats

| Format | When | How it is made |
|---|---|---|
| Text + image | Default | Image: a real photo of the member or their work, or a simple card from `render_linkedin.mjs` (layout `card`, 1200 × 1500). No stock photos. Draft **alt text** for every image (what it shows, in one sentence; LinkedIn's "Add alt text" on upload), in the render spec as `alt` |
| Document carousel | Once a week, for a method, checklist or framework | `render_linkedin.mjs` layout `carousel`: 5 to 10 slides at 1080 × 1350, a hook slide, one idea per slide, a final slide with the soft CTA, exported as a PDF to upload as a document. Draft the **document title** (asked for on upload and shown with the document in the feed; keep it to the hook, about 60 characters [Build Room; check on the live upload screen]); it goes in the render spec as `title` so it travels with the PDF in the render report and the post text that goes above it |
| Video | Trust with people who already follow; a short explanation to camera | Hand to the **Video Director** (content playbook: "Make me a content video") with the post as the brief; the post text must match the video |
| Poll | Only to learn something real about the buyers, followed by a results post | Text only |
| Newsletter | Optional, once the member has about 500 followers: the first issue invites the whole network once | Halbert; one issue a fortnight or month; each issue becomes three posts (hub and spoke, Welsh) |

## 8. The post gate (before the member sees a draft as "ready")

Show the gate filled in under every draft. A draft that fails a line is fixed before the member sees it.

**Truth and permission**
- [ ] Built on the member's own story or fact (named in the draft notes); nothing invented: no added detail about a client (gender, age, backstory) that the story bank does not hold
- [ ] Every number and name traceable to the file or the story bank
- [ ] Client names, and client words even when unnamed, only with consent recorded in the story bank
- [ ] Proof claims ("I've helped…", results, before and after) only from consented proof in §5 or §18
- [ ] No §18 never-say claim
- [ ] No offer element still open in §3 or §13 (guarantee wording, number of places, price) unless the member confirmed it in this session
- [ ] No retired line (§1), and no paraphrase of one

**Craft**
- [ ] On one of the pillars, and the topic is clear inside the first 140 characters
- [ ] Character count shown; the length fits the post's job (§6)
- [ ] Kern for LinkedIn checks pass (§6); no AI tells; the three tests pass
- [ ] No story used twice within four weeks, unless the calendar plans it as hub and spoke
- [ ] Draft label and facts list present

**Platform**
- [ ] No bait, no comment-gating, no "agree?", no tags of uninvolved people
- [ ] At most one link; the call to action is soft unless this is the scheduled offer post
- [ ] Format matches the week's plan; a carousel or card is rendered and checked; document title and alt text drafted

## 9. The calendar

`linkedin/calendar.md`: four weeks ahead, three posts a week, each with the pillar, the archetype, the story it uses, the format, the planned day, and its status (idea, drafted, approved, posted with link). The member schedules with LinkedIn's own scheduler or posts by hand, then tells the skill "posted" with the link.
